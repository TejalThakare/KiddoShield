package com.example.RegisterLogin.Service;
import com.example.RegisterLogin.Entity.User;
import com.example.RegisterLogin.Entity.Child;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.log.LogMessage;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

import com.example.RegisterLogin.Dto.ChildDto;
import com.example.RegisterLogin.Dto.LoginDto;
import com.example.RegisterLogin.payload.response.LoginMesage;
import com.example.RegisterLogin.Dto.UserDto;
import com.example.RegisterLogin.Repo.ChildRepo;
import com.example.RegisterLogin.Repo.UserRepo;

@Service

public class UserServiceImpl implements UserService {

    @Autowired
    private UserRepo UserRepo;
    @Autowired
    private ChildRepo childrepo;

    @Autowired
    private PasswordEncoder passwordEncoder;


    @Override
    public String addUser(UserDto UserDto) {

        User User = new User(

        		UserDto.getUid(),
        		UserDto.getFname(),
        		UserDto.getLname(),
        		UserDto.getUsername(),
        		UserDto.getEmail(),
        		UserDto.getAddress(),
        		UserDto.getContact(),

               this.passwordEncoder.encode(UserDto.getPassword())
        );

        UserRepo.save(User);

        return User.getFname() ;
    }
    UserDto UserDto;

    @Override
    public LoginMesage  loginUser(LoginDto loginDto) {
        String msg = "";
        User user1 = UserRepo.findByEmail(loginDto.getEmail());
        if (user1 != null) {
            String password = loginDto.getPassword();
            String encodedPassword =user1.getPassword();
            Boolean isPwdRight = passwordEncoder.matches(password, encodedPassword);
            if (isPwdRight) {
            	Optional<User> user = UserRepo.findOneByEmailAndPassword(loginDto.getEmail(), encodedPassword);
                if (user.isPresent()) {
                    return new LoginMesage("Login Success", true);
                } else {
                    return new LoginMesage("Login Failed", false);
                }
            } else {

                return new LoginMesage("password Not Match", false);
            }
        }else {
            return new LoginMesage("Email not exits", false);
        }


    }

	@Override
	public String addChild(ChildDto childdto) {
		Child child=new Child(
				childdto.getCid(),
				childdto.getCfname(),
				childdto.getAge(),
				childdto.getWeight(),
				childdto.getBloodgrp(),
				childdto.getGender(),
				childdto.getDob(),
				childdto.getUser()
				);
		childrepo.save(child);
		return child.getCfname();
	}

}