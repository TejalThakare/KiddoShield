package com.example.RegisterLogin.Service;

import com.example.RegisterLogin.Dto.ChildDto;
import com.example.RegisterLogin.Dto.LoginDto;
import com.example.RegisterLogin.Dto.UserDto;
import com.example.RegisterLogin.payload.response.LoginMesage;


public interface UserService {
	String addUser(UserDto UserDto);
	LoginMesage loginUser(LoginDto LoginDtO);
	String addChild(ChildDto childdto);
}
