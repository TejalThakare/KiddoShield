package com.example.RegisterLogin.UserController;


import com.example.RegisterLogin.Dto.UserDto;
import com.example.RegisterLogin.Dto.ChildDto;
import com.example.RegisterLogin.Dto.LoginDto;
import com.example.RegisterLogin.Service.UserService;
import com.example.RegisterLogin.payload.response.LoginMesage;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@CrossOrigin
@RequestMapping("api/User")
public class UserController {


    @Autowired
    private UserService userService;


    @PostMapping(path = "/Register")
    public String RegisterUser(@RequestBody UserDto userDto)
    {
        String id = userService.addUser(userDto);
        return id;
    }

    @PostMapping(path = "/login")
    public ResponseEntity<?> loginUser(@RequestBody LoginDto loginDto)
    {
        LoginMesage loginResponse = userService.loginUser(loginDto);
        return ResponseEntity.ok(loginResponse);
    }
    
    public String RegisterChild(@RequestBody ChildDto childDto) {
    	String id=userService.addChild(childDto);
    	return id;
    }
    }
