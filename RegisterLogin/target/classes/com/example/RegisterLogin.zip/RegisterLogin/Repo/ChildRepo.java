package com.example.RegisterLogin.Repo;

import org.springframework.data.jpa.repository.JpaRepository;

import com.example.RegisterLogin.Entity.Child;

public interface ChildRepo extends JpaRepository<Child,String>{

}
